plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.glasshelloworld"
    compileSdk = 33

    defaultConfig {
        applicationId = "com.example.glasshelloworld"
        minSdk = 19  // Glass Explorer runs on API 19 (KitKat)
        targetSdk = 33
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }

    // Add this to enable TensorFlow Lite
    aaptOptions {
        noCompress("tflite")
    }

    // Prevent errors with duplicate classes
    packagingOptions {
        exclude("META-INF/DEPENDENCIES")
        exclude("META-INF/LICENSE")
        exclude("META-INF/LICENSE.txt")
        exclude("META-INF/license.txt")
        exclude("META-INF/NOTICE")
        exclude("META-INF/NOTICE.txt")
        exclude("META-INF/notice.txt")
        exclude("META-INF/*.kotlin_module")
    }
}

dependencies {
    // Glass GDK reference
    implementation(files("libs/gdk.jar"))

    // Use a basic TensorFlow Lite version that's compatible with API 19
    implementation("org.tensorflow:tensorflow-lite:2.3.0")

    // Basic Android dependencies
    implementation("androidx.core:core-ktx:1.3.2")
    implementation("androidx.appcompat:appcompat:1.2.0")
}