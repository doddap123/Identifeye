package com.example.glasshelloworld

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.provider.MediaStore
import android.speech.RecognizerIntent
import android.util.Log
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import android.view.View
import android.graphics.BitmapFactory
import android.hardware.Camera
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class FaceEnrollmentActivity : Activity() {
    private val TAG = "FaceEnrollmentActivity"
    private val REQUEST_IMAGE_CAPTURE = 1001
    private val REQUEST_SPEECH_INPUT = 1002
    private val FILE_TEMP_IMAGE = "temp_face.jpg"

    private lateinit var nameInput: EditText
    private lateinit var captureButton: Button
    private lateinit var saveButton: Button
    private lateinit var previewImage: ImageView
    private lateinit var statusText: TextView

    private var captureBitmap: Bitmap? = null
    private lateinit var faceRecognitionHelper: FaceRecognitionHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_face_enrollment)

        // Initialize views
        nameInput = findViewById(R.id.nameInput)
        captureButton = findViewById(R.id.captureButton)
        saveButton = findViewById(R.id.saveButton)
        previewImage = findViewById(R.id.previewImage)
        statusText = findViewById(R.id.statusText)

        // Disable buttons initially
        captureButton.isEnabled = false
        saveButton.isEnabled = false

        // Initialize face recognition helper
        faceRecognitionHelper = FaceRecognitionHelper(this)

        // Update your capture button click handler
        captureButton.setOnClickListener {
            captureImageDirectly() // Use direct capture instead of intent
        }

        saveButton.setOnClickListener {
            saveFace()
        }

        // Add touch listener for nameInput to trigger voice input manually
        nameInput.setOnClickListener {
            startSpeechRecognition()
        }

        // Add instructions for Glass users
        statusText.text = "TAP to input name by voice first"

        // Set initial focus on name input and start voice recognition immediately
        nameInput.requestFocus()
        startSpeechRecognition()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        Log.d(TAG, "Key down: $keyCode")
        // Handle Glass touchpad tap
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER) {
            Log.d(TAG, "Touchpad tapped")
            // If name input has focus, start speech recognition
            if (nameInput.hasFocus()) {
                Log.d(TAG, "Name input has focus, starting speech recognition")
                startSpeechRecognition()
                return true
            }
            // If capture button is visible and enabled, trigger it
            else if (captureButton.isEnabled) {
                Log.d(TAG, "Triggering capture button")
                captureButton.performClick()
                return true
            }
            // If save button is visible and enabled, trigger it
            else if (saveButton.isEnabled) {
                Log.d(TAG, "Triggering save button")
                saveButton.performClick()
                return true
            }
            // If the image is showing but no name yet, prompt for name
            else if (previewImage.visibility == View.VISIBLE && nameInput.text.toString().isEmpty()) {
                Log.d(TAG, "Image showing but no name, prompting for name")
                nameInput.requestFocus()
                startSpeechRecognition()
                return true
            }
        }

        // Handle back key
        else if (keyCode == KeyEvent.KEYCODE_BACK) {
            Log.d(TAG, "Back key pressed, returning to camera preview")
            val intent = Intent(this, CameraPreviewActivity::class.java)
            startActivity(intent)
            finish()
            return true
        }

        return super.onKeyDown(keyCode, event)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Add menu option for voice input
        menu.add(0, 1, 0, "Voice Input").setIcon(android.R.drawable.ic_btn_speak_now)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == 1) {
            startSpeechRecognition()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun processCapturedImage(bitmap: Bitmap) {
        Log.d(TAG, "Processing captured image")
        if (bitmap != null) {
            previewImage.setImageBitmap(bitmap)
            previewImage.visibility = View.VISIBLE
            captureBitmap = bitmap

            // Detect if there's a face
            val faces = faceRecognitionHelper.detectFaces(bitmap)
            Log.d(TAG, "Detected ${faces.size} faces in image")

            if (faces.isEmpty()) {
                statusText.text = "No face detected! TAP to try again."
                captureButton.requestFocus()
            } else if (faces.size > 1) {
                statusText.text = "Multiple faces detected! TAP to try again."
                captureButton.requestFocus()
            } else {
                // Valid face detected
                statusText.text = "Face detected! Processing..."
                Log.d(TAG, "Valid face detected, preparing to save")

                // Important: Save the face data immediately
                try {
                    val name = nameInput.text.toString().trim()
                    val faceRect = faces[0]

                    Log.d(TAG, "Extracting face bitmap")
                    val faceBitmap = faceRecognitionHelper.extractFaceBitmap(bitmap, faceRect)

                    Log.d(TAG, "Generating face embedding")
                    val faceEmbedding = faceRecognitionHelper.getFaceEmbedding(faceBitmap)

                    Log.d(TAG, "Saving face data for: $name")
                    saveFaceData(name, faceEmbedding)

                    statusText.text = "Face saved successfully!"
                    Toast.makeText(this, "Face for $name saved successfully!", Toast.LENGTH_SHORT).show()
                    Log.d(TAG, "Face data saved successfully for: $name")

                    // Return to camera preview after a delay
                    Handler().postDelayed({
                        Log.d(TAG, "Returning to camera preview")
                        val intent = Intent(this, CameraPreviewActivity::class.java)
                        startActivity(intent)
                        finish()
                    }, 2000)
                } catch (e: Exception) {
                    Log.e(TAG, "Error processing face: ${e.message}")
                    statusText.text = "Error processing face: ${e.message}"
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            REQUEST_IMAGE_CAPTURE -> if (resultCode == RESULT_OK) {
                Log.d(TAG, "Camera returned successfully")

                try {
                    // Load the image from the file
                    val tempImageFile = File(filesDir, FILE_TEMP_IMAGE)
                    if (tempImageFile.exists()) {
                        Log.d(TAG, "Loading image from file: ${tempImageFile.absolutePath}")

                        // Decode the image file into a bitmap
                        val options = android.graphics.BitmapFactory.Options()
                        options.inPreferredConfig = Bitmap.Config.ARGB_8888

                        val bitmap = android.graphics.BitmapFactory.decodeFile(
                            tempImageFile.absolutePath, options)

                        if (bitmap != null) {
                            Log.d(TAG, "Successfully loaded bitmap from file")
                            processCapturedImage(bitmap)
                        } else {
                            Log.e(TAG, "Failed to decode bitmap from file")
                            statusText.text = "Error loading captured image"
                        }
                    } else {
                        Log.e(TAG, "Image file does not exist")
                        statusText.text = "Error: Captured image not found"
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error processing camera result: ${e.message}")
                    statusText.text = "Error: ${e.message}"
                }
            }

            REQUEST_SPEECH_INPUT -> if (resultCode == RESULT_OK) {
                val result = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                if (!result.isNullOrEmpty()) {
                    nameInput.setText(result[0])
                    statusText.text = "Name captured: ${result[0]}. TAP to capture face."
                    captureButton.isEnabled = true
                    captureButton.requestFocus()
                    Log.d(TAG, "Name captured, enabling capture button")
                }
            }
        }
    }

    private fun captureImageDirectly() {
        Log.d(TAG, "Setting up direct camera capture")

        // Create a simple camera preview
        val surfaceView = SurfaceView(this)
        val holder = surfaceView.holder

        holder.addCallback(object : SurfaceHolder.Callback {
            private var camera: Camera? = null

            override fun surfaceCreated(holder: SurfaceHolder) {
                try {
                    // Open camera
                    camera = Camera.open()
                    camera?.setPreviewDisplay(holder)
                    camera?.startPreview()

                    // Take picture after a short delay to allow preview to start
                    Handler().postDelayed({
                        camera?.takePicture(null, null, { data, camera ->
                            try {
                                Log.d(TAG, "Picture taken, data size: ${data.size}")
                                // Convert byte array to bitmap
                                val bitmap = BitmapFactory.decodeByteArray(data, 0, data.size)
                                if (bitmap != null) {
                                    // Process the bitmap
                                    processFaceDetection(bitmap)
                                } else {
                                    Log.e(TAG, "Failed to decode bitmap from camera data")
                                    statusText.text = "Error: Could not decode image"
                                }

                                // Release camera
                                camera.release()
                                // Remove temporary surface view
                                (surfaceView.parent as? ViewGroup)?.removeView(surfaceView)
                            } catch (e: Exception) {
                                Log.e(TAG, "Error processing camera image: ${e.message}")
                                statusText.text = "Camera error: ${e.message}"
                            }
                        })
                    }, 1000)
                } catch (e: Exception) {
                    Log.e(TAG, "Error setting up camera: ${e.message}")
                    statusText.text = "Camera error: ${e.message}"
                }
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                // Do nothing
            }

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                camera?.release()
                camera = null
            }
        })

        // Add camera preview to layout temporarily
        val layout = findViewById<ViewGroup>(android.R.id.content)
        layout.addView(surfaceView)

        statusText.text = "Taking picture..."
    }

    // Add this method to process the face
    private fun processFaceDetection(bitmap: Bitmap) {
        try {
            Log.d(TAG, "Processing face detection")
            // Show preview
            previewImage.setImageBitmap(bitmap)
            previewImage.visibility = View.VISIBLE
            captureBitmap = bitmap

            // Detect faces with improved implementation
            Log.d(TAG, "Starting face detection on bitmap ${bitmap.width}x${bitmap.height}")
            val faces = faceRecognitionHelper.detectFaces(bitmap)
            Log.d(TAG, "Detected ${faces.size} faces")

            if (faces.isEmpty()) {
                statusText.text = "No face detected! Try again."
                captureButton.isEnabled = true
                return
            }

            // Get name from input
            val name = nameInput.text.toString().trim()
            if (name.isEmpty()) {
                statusText.text = "Please enter a name first"
                nameInput.requestFocus()
                startSpeechRecognition()
                return
            }

            // Process in background to avoid freezing UI
            Thread {
                try {
                    // Get the first face
                    val faceRect = faces[0]
                    Log.d(TAG, "Face rectangle: $faceRect")

                    runOnUiThread {
                        statusText.text = "Processing face..."
                    }

                    Log.d(TAG, "Extracting face from bitmap")
                    val faceBitmap = faceRecognitionHelper.extractFaceBitmap(bitmap, faceRect)
                    Log.d(TAG, "Extracted face bitmap ${faceBitmap.width}x${faceBitmap.height}")

                    Log.d(TAG, "Generating face embedding")
                    val faceEmbedding = faceRecognitionHelper.getFaceEmbedding(faceBitmap)
                    Log.d(TAG, "Generated face embedding with length: ${faceEmbedding.size}")

                    // Save the face data
                    Log.d(TAG, "Saving face data for: $name")
                    saveFaceData(name, faceEmbedding)
                    Log.d(TAG, "Face data saved successfully")

                    runOnUiThread {
                        statusText.text = "Face saved for $name!"
                        Toast.makeText(this, "Face data saved!", Toast.LENGTH_SHORT).show()

                        // Return to camera preview after a delay
                        Handler().postDelayed({
                            val intent = Intent(this, CameraPreviewActivity::class.java)
                            startActivity(intent)
                            finish()
                        }, 2000)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error in face processing: ${e.message}", e)
                    runOnUiThread {
                        statusText.text = "Error: ${e.message}"
                        captureButton.isEnabled = true
                    }
                }
            }.start()
        } catch (e: Exception) {
            Log.e(TAG, "Error in face processing: ${e.message}", e)
            statusText.text = "Error: ${e.message}"
            captureButton.isEnabled = true
        }
    }

    private fun saveFace() {
        val name = nameInput.text.toString().trim()
        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter a name", Toast.LENGTH_SHORT).show()
            startSpeechRecognition()  // Prompt for voice input if name is empty
            return
        }

        if (captureBitmap == null) {
            Toast.makeText(this, "Please capture a face first", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            // Detect faces
            val faces = faceRecognitionHelper.detectFaces(captureBitmap!!)
            if (faces.isEmpty()) {
                Toast.makeText(this, "No face detected in the image", Toast.LENGTH_SHORT).show()
                return
            }

            // Get the first face
            val faceRect = faces[0]

            // Extract face embedding
            val faceBitmap = faceRecognitionHelper.extractFaceBitmap(captureBitmap!!, faceRect)
            val faceEmbedding = faceRecognitionHelper.getFaceEmbedding(faceBitmap)

            // Save the embedding with the name
            saveFaceData(name, faceEmbedding)

            Toast.makeText(this, "Face saved successfully!", Toast.LENGTH_SHORT).show()

            // Start camera preview activity
            val intent = Intent(this, CameraPreviewActivity::class.java)
            startActivity(intent)
            finish()
        } catch (e: Exception) {
            Log.e(TAG, "Error saving face: ${e.message}")
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveFaceData(name: String, embedding: FloatArray) {
        try {
            Log.d(TAG, "Starting face data save for $name with embedding length: ${embedding.size}")

            // Load existing face data
            val facesFile = File(filesDir, "known_faces.json")
            var jsonObject = if (facesFile.exists()) {
                Log.d(TAG, "Found existing faces file")
                val jsonContent = facesFile.readText()
                JSONObject(jsonContent)
            } else {
                Log.d(TAG, "Creating new faces file")
                JSONObject()
            }

            // Create or get the "faces" array
            var facesArray = if (jsonObject.has("faces")) {
                jsonObject.getJSONArray("faces")
            } else {
                JSONArray()
            }

            // Check if we already have this person
            var existingIndex = -1
            for (i in 0 until facesArray.length()) {
                val face = facesArray.getJSONObject(i)
                if (face.getString("name") == name) {
                    existingIndex = i
                    break
                }
            }

            // Create a new face entry
            val faceObject = JSONObject()
            faceObject.put("name", name)

            // Convert embedding to JSON array
            val embeddingArray = JSONArray()
            for (value in embedding) {
                embeddingArray.put(value)
            }
            faceObject.put("embedding", embeddingArray)

            // Add to faces array (or replace existing)
            if (existingIndex >= 0) {
                Log.d(TAG, "Updating existing face for $name")
                facesArray.put(existingIndex, faceObject)
            } else {
                Log.d(TAG, "Adding new face for $name")
                facesArray.put(faceObject)
            }

            // Update the main JSON object
            jsonObject.put("faces", facesArray)

            // Save to file
            Log.d(TAG, "Writing faces file, size: ${jsonObject.toString().length} bytes")
            FileOutputStream(facesFile).use {
                it.write(jsonObject.toString().toByteArray())
            }

            Log.d(TAG, "Saved face data for $name")
        } catch (e: Exception) {
            Log.e(TAG, "Error saving face data: ${e.message}", e)
            throw e
        }
    }

    // Speech recognition starter with Glass-specific settings
    private fun startSpeechRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say the person's name")

        // Google Glass specific extras
        intent.putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf<String>())
        intent.putExtra("android.speech.extra.DICTATION_MODE", true)

        try {
            startActivityForResult(intent, REQUEST_SPEECH_INPUT)
        } catch (e: Exception) {
            Toast.makeText(this, "Speech recognition not available", Toast.LENGTH_SHORT).show()
            Log.e(TAG, "Error starting speech recognition: ${e.message}")
        }
    }

    companion object {
        fun start(context: Context) {
            val intent = Intent(context, FaceEnrollmentActivity::class.java)
            context.startActivity(intent)
        }
    }
}