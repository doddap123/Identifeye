package com.example.glasshelloworld

import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.SurfaceTexture
import android.hardware.Camera
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.view.SurfaceHolder
import android.widget.RemoteViews
import com.google.android.glass.timeline.LiveCard

class SimpleCameraPreviewService : Service() {
    private val TAG = "CameraService"
    private val LIVE_CARD_TAG = "CameraCard"

    private var mLiveCard: LiveCard? = null
    private var mCamera: Camera? = null
    private var mHandler = Handler(Looper.getMainLooper())
    private var mUpdateTextRunnable: Runnable? = null
    private var mRemoteViews: RemoteViews? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (mLiveCard == null) {
            Log.d(TAG, "Creating new LiveCard")
            mLiveCard = LiveCard(this, LIVE_CARD_TAG)

            // Set up RemoteViews for text display
            mRemoteViews = RemoteViews(packageName, R.layout.facial_recognition_card)
            mLiveCard?.setViews(mRemoteViews)

            // Update text initially
            mRemoteViews?.setTextViewText(R.id.status_text, "CAMERA PREVIEW - STARTING")
            mLiveCard?.setViews(mRemoteViews)

            // Set up tap action to go back to this service, not MainActivity
            val serviceIntent = Intent(this, SimpleCameraPreviewService::class.java)
            val pendingIntent = PendingIntent.getService(
                this, 0, serviceIntent, PendingIntent.FLAG_UPDATE_CURRENT
            )
            mLiveCard?.setAction(pendingIntent)

            // Start camera preview in background
            startCameraInBackground()

            // Publish the LiveCard
            mLiveCard?.publish(LiveCard.PublishMode.REVEAL)
            Log.d(TAG, "LiveCard published")

            // Start updating text
            startTextUpdates()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        Log.d(TAG, "onDestroy called")
        stopTextUpdates()
        releaseCamera()
        if (mLiveCard != null) {
            mLiveCard?.unpublish()
            mLiveCard = null
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    private fun startCameraInBackground() {
        Thread {
            try {
                mCamera = Camera.open()

                // Configure camera parameters
                val parameters = mCamera?.parameters
                parameters?.let {
                    if (it.supportedFocusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                        it.focusMode = Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE
                    }
                    mCamera?.parameters = it
                }

                // Use a dummy SurfaceTexture to start preview without rendering
                // This lets us have camera running in background for other processing
                mCamera?.setPreviewTexture(SurfaceTexture(0))
                mCamera?.startPreview()

                // Update UI on main thread
                mHandler.post {
                    mRemoteViews?.setTextViewText(R.id.status_text, "CAMERA ACTIVE")
                    mLiveCard?.setViews(mRemoteViews)
                }

                Log.d(TAG, "Camera preview started")
            } catch (e: Exception) {
                Log.e(TAG, "Error starting camera: ${e.message}")
                e.printStackTrace()
                releaseCamera()

                // Update UI to show error
                mHandler.post {
                    mRemoteViews?.setTextViewText(R.id.status_text, "CAMERA ERROR: ${e.message}")
                    mLiveCard?.setViews(mRemoteViews)
                }
            }
        }.start()
    }

    private fun releaseCamera() {
        if (mCamera != null) {
            try {
                mCamera?.stopPreview()
                mCamera?.release()
                Log.d(TAG, "Camera released")
            } catch (e: Exception) {
                Log.e(TAG, "Error releasing camera: ${e.message}")
            } finally {
                mCamera = null
            }
        }
    }

    private fun startTextUpdates() {
        mUpdateTextRunnable = object : Runnable {
            override fun run() {
                try {
                    if (mCamera != null) {
                        // Update text with timestamp if camera is active
                        val text = "CAMERA ACTIVE - " + System.currentTimeMillis()
                        mRemoteViews?.setTextViewText(R.id.status_text, text)
                        mLiveCard?.setViews(mRemoteViews)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error updating text: ${e.message}")
                }

                // Schedule next update
                mHandler.postDelayed(this, 1000)
            }
        }
        mHandler.post(mUpdateTextRunnable!!)
    }

    private fun stopTextUpdates() {
        mUpdateTextRunnable?.let {
            mHandler.removeCallbacks(it)
        }
    }
}