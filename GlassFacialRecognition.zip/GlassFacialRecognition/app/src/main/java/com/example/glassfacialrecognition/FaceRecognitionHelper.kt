package com.example.glasshelloworld

import android.content.Context
import android.content.res.AssetFileDescriptor
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.RectF
import android.media.FaceDetector
import android.util.Log
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import android.graphics.PointF
import java.io.File
import org.json.JSONObject
import org.json.JSONArray
import java.util.*

class FaceRecognitionHelper(private val context: Context) {
    private val TAG = "FaceRecognitionHelper"

    // TFLite interpreter
    private var interpreter: Interpreter? = null

    // Known face data
    private val knownFaceEncodings = mutableListOf<FloatArray>()
    private val knownFaceNames = mutableListOf<String>()

    // Model parameters
    private val INPUT_SIZE = 112
    private val EMBEDDING_SIZE = 192  // Changed from 128 to match model output

    // Maximum number of faces to detect
    private val MAX_FACES = 3

    init {
        try {
            // Load the TFLite model
            val modelBuffer = loadModelFile("mobile_face_net.tflite")
            val options = Interpreter.Options()
            interpreter = Interpreter(modelBuffer, options)

            // Load known faces
            loadKnownFaces()

            Log.d(TAG, "Model loaded successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing face recognition: ${e.message}")
            e.printStackTrace()
        }
    }

    private fun loadModelFile(modelPath: String): MappedByteBuffer {
        val fileDescriptor: AssetFileDescriptor = context.assets.openFd(modelPath)
        val inputStream = FileInputStream(fileDescriptor.fileDescriptor)
        val fileChannel = inputStream.channel
        val startOffset = fileDescriptor.startOffset
        val declaredLength = fileDescriptor.declaredLength
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength)
    }

    fun detectFaces(bitmap: Bitmap): List<Rect> {
        Log.d(TAG, "Starting face detection on bitmap ${bitmap.width}x${bitmap.height}")

        // Convert bitmap to a format suitable for FaceDetector
        val convertedBitmap = bitmap.copy(Bitmap.Config.RGB_565, true)

        // Use Android's built-in face detector
        val faceDetector = FaceDetector(
            convertedBitmap.width,
            convertedBitmap.height,
            MAX_FACES
        )

        val faces = arrayOfNulls<FaceDetector.Face>(MAX_FACES)
        val facesFound = faceDetector.findFaces(convertedBitmap, faces)

        Log.d(TAG, "Found $facesFound faces")

        val faceRects = mutableListOf<Rect>()

        if (facesFound > 0) {
            for (i in 0 until facesFound) {
                val face = faces[i] ?: continue
                val midPoint = PointF()
                face.getMidPoint(midPoint)

                // Get confidence score
                val confidence = face.confidence()
                Log.d(TAG, "Face $i confidence: $confidence")

                // Only include faces with reasonable confidence
                if (confidence > 0.3f) {
                    // Use eye distance to estimate face size
                    val eyeDistance = face.eyesDistance()

                    // Create a rectangle with the face
                    // Make it a bit larger than just the eye distance for better results
                    val rectWidth = eyeDistance * 3
                    val rectHeight = eyeDistance * 4

                    val rect = Rect(
                        (midPoint.x - rectWidth/2).toInt().coerceAtLeast(0),
                        (midPoint.y - rectHeight/2).toInt().coerceAtLeast(0),
                        (midPoint.x + rectWidth/2).toInt().coerceAtMost(bitmap.width),
                        (midPoint.y + rectHeight/2).toInt().coerceAtMost(bitmap.height)
                    )

                    faceRects.add(rect)
                }
            }
        }

        // Clean up
        convertedBitmap.recycle()

        return faceRects
    }

    // Replace the existing recognizeFace method with this one
    fun recognizeFace(bitmap: Bitmap, faceRect: Rect, threshold: Float = 0.9f): String {
        try {
            // Extract face from bitmap
            val faceBitmap = extractFaceBitmap(bitmap, faceRect)

            // Get face embedding
            val faceEmbedding = getFaceEmbedding(faceBitmap)

            // Compare with known faces
            var bestMatchName = "Unknown"
            var bestMatchDistance = Float.MAX_VALUE

            // Display distances for debugging
            val distances = StringBuilder()

            for (i in knownFaceEncodings.indices) {
                val distance = calculateDistance(faceEmbedding, knownFaceEncodings[i])
                distances.append("${knownFaceNames[i]}: $distance, ")

                if (distance < bestMatchDistance && distance < threshold) {
                    bestMatchDistance = distance
                    bestMatchName = knownFaceNames[i]
                }
            }

            Log.d(TAG, "Face distances: $distances")
            Log.d(TAG, "Best match: $bestMatchName with distance: $bestMatchDistance")

            return bestMatchName
        } catch (e: Exception) {
            Log.e(TAG, "Error recognizing face: ${e.message}")
            return "Error"
        }
    }

    fun extractFaceBitmap(bitmap: Bitmap, rect: Rect): Bitmap {
        try {
            // Create a properly sized bitmap containing just the face
            val faceBitmap = Bitmap.createBitmap(
                INPUT_SIZE, INPUT_SIZE, Bitmap.Config.ARGB_8888
            )

            // Set up a matrix to scale the face region to the required size
            val transform = Matrix()
            val sourceRect = RectF(
                rect.left.toFloat(),
                rect.top.toFloat(),
                rect.right.toFloat(),
                rect.bottom.toFloat()
            )
            val destRect = RectF(0f, 0f, INPUT_SIZE.toFloat(), INPUT_SIZE.toFloat())

            transform.setRectToRect(sourceRect, destRect, Matrix.ScaleToFit.FILL)

            // Draw the face region into the new bitmap
            val canvas = android.graphics.Canvas(faceBitmap)
            canvas.drawBitmap(bitmap, transform, null)

            return faceBitmap
        } catch (e: Exception) {
            Log.e(TAG, "Error extracting face bitmap: ${e.message}")
            throw e
        }
    }

    fun getFaceEmbedding(faceBitmap: Bitmap): FloatArray {
        try {
            // Convert bitmap to ByteBuffer for TFLite input
            val byteBuffer = ByteBuffer.allocateDirect(1 * INPUT_SIZE * INPUT_SIZE * 3 * 4)
            byteBuffer.order(ByteOrder.nativeOrder())

            val pixels = IntArray(INPUT_SIZE * INPUT_SIZE)
            faceBitmap.getPixels(pixels, 0, faceBitmap.width, 0, 0, faceBitmap.width, faceBitmap.height)

            for (pixel in pixels) {
                // Extract RGB values
                val r = (pixel shr 16) and 0xFF
                val g = (pixel shr 8) and 0xFF
                val b = pixel and 0xFF

                // Normalize to range [-1, 1]
                byteBuffer.putFloat((r - 127.5f) / 127.5f)
                byteBuffer.putFloat((g - 127.5f) / 127.5f)
                byteBuffer.putFloat((b - 127.5f) / 127.5f)
            }

            // Prepare output with correct size (EMBEDDING_SIZE = 192)
            val outputBuffer = Array(1) { FloatArray(EMBEDDING_SIZE) }

            // Reset buffer position for reading
            byteBuffer.rewind()

            // Run the model
            interpreter?.run(byteBuffer, outputBuffer)

            // Normalize the embedding vector
            val embedding = outputBuffer[0]
            var sum = 0f
            for (value in embedding) {
                sum += value * value
            }
            val norm = Math.sqrt(sum.toDouble()).toFloat()
            for (i in embedding.indices) {
                embedding[i] /= norm
            }

            return embedding
        } catch (e: Exception) {
            Log.e(TAG, "Error getting face embedding: ${e.message}", e)
            throw e
        }
    }

    private fun loadKnownFaces() {
        try {
            // Clear existing data first
            knownFaceNames.clear()
            knownFaceEncodings.clear()

            val facesFile = File(context.filesDir, "known_faces.json")
            Log.d(TAG, "Looking for faces file at: ${facesFile.absolutePath}")

            if (facesFile.exists()) {
                Log.d(TAG, "Found faces file, size: ${facesFile.length()} bytes")
                val jsonContent = facesFile.readText()
                Log.d(TAG, "JSON content length: ${jsonContent.length}")

                val jsonObject = JSONObject(jsonContent)

                if (jsonObject.has("faces")) {
                    val facesArray = jsonObject.getJSONArray("faces")
                    Log.d(TAG, "JSON contains ${facesArray.length()} faces")

                    for (i in 0 until facesArray.length()) {
                        val faceObject = facesArray.getJSONObject(i)
                        val name = faceObject.getString("name")

                        if (faceObject.has("embedding")) {
                            val embeddingArray = faceObject.getJSONArray("embedding")
                            Log.d(TAG, "Loading face for $name with embedding size: ${embeddingArray.length()}")

                            val embedding = FloatArray(EMBEDDING_SIZE)
                            // Make sure we don't go out of bounds
                            val minLength = Math.min(embeddingArray.length(), EMBEDDING_SIZE)
                            for (j in 0 until minLength) {
                                embedding[j] = embeddingArray.getDouble(j).toFloat()
                            }

                            knownFaceNames.add(name)
                            knownFaceEncodings.add(embedding)
                            Log.d(TAG, "Successfully loaded face for: $name")
                        } else {
                            Log.e(TAG, "Face object for $name missing embedding array")
                        }
                    }

                    Log.d(TAG, "Loaded ${knownFaceNames.size} known faces")

                    // Debug: print first few values of first embedding if available
                    if (knownFaceEncodings.isNotEmpty()) {
                        val firstEmbedding = knownFaceEncodings[0]
                        val preview = firstEmbedding.take(5).joinToString(", ")
                        Log.d(TAG, "First embedding starts with: $preview...")
                    }
                } else {
                    Log.e(TAG, "JSON doesn't contain 'faces' array")
                }
            } else {
                Log.d(TAG, "No saved faces found")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error loading known faces: ${e.message}", e)
        }
    }

    private fun calculateDistance(embedding1: FloatArray, embedding2: FloatArray): Float {
        // Use Euclidean distance
        var sum = 0f
        for (i in 0 until Math.min(embedding1.size, embedding2.size)) {
            val diff = embedding1[i] - embedding2[i]
            sum += diff * diff
        }
        return Math.sqrt(sum.toDouble()).toFloat()
    }

    fun cleanup() {
        interpreter?.close()
        interpreter = null
    }
}