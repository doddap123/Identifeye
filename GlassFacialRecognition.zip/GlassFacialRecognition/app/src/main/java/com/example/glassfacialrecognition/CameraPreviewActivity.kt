package com.example.glasshelloworld

import android.app.Activity
import android.content.Intent
import android.view.WindowManager

// Add this import at the top of your file
import android.view.View
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.Camera
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import java.io.IOException

class CameraPreviewActivity : Activity(), SurfaceHolder.Callback, Camera.PreviewCallback {
    private val TAG = "CameraPreviewActivity"

    private var mCamera: Camera? = null
    private var mSurfaceView: SurfaceView? = null
    private var mSurfaceHolder: SurfaceHolder? = null
    private var mStatusText: TextView? = null
    private var mFaceRecognitionHelper: FaceRecognitionHelper? = null

    // Processing flags
    private var isProcessingFrame = false
    private val processEveryNFrames = 50
    private var frameCounter = 0
    // Face overlay
    private var mOverlayView: OverlayView? = null

    // Gesture detection for Glass
    private var xDown = 0f
    private var yDown = 0f

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_enroll_face -> {
                FaceEnrollmentActivity.start(this)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep the screen on while the app is running
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Initialize face recognition
        mFaceRecognitionHelper = FaceRecognitionHelper(this)

        // Create our layout container
        val layout = FrameLayout(this)
        layout.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )

        // Create and add the SurfaceView for camera preview
        mSurfaceView = SurfaceView(this)
        mSurfaceView?.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        layout.addView(mSurfaceView)

        // Add overlay view for drawing face boxes
        mOverlayView = OverlayView(this)
        mOverlayView?.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )

        // Make sure the overlay is visible
        mOverlayView?.visibility = View.VISIBLE
        mOverlayView?.setBackgroundColor(Color.TRANSPARENT)

        layout.addView(mOverlayView)
        Log.d(TAG, "Added overlay view to layout")

        // Create and add TextView for status overlay
        mStatusText = TextView(this)
        mStatusText?.apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                // Position at bottom of screen
                bottomMargin = 50
            }
            text = "Starting camera...\nTap to open menu, swipe down to enroll face"
            setTextColor(Color.YELLOW)
            textSize = 18f
            setPadding(16, 16, 16, 16)
            setBackgroundColor(0x80000000.toInt())  // Semi-transparent black
        }
        layout.addView(mStatusText)

        // Set our layout as the content view
        setContentView(layout)

        // Get the SurfaceHolder and add callback
        mSurfaceHolder = mSurfaceView?.holder
        mSurfaceHolder?.addCallback(this)
        mSurfaceHolder?.setFormat(PixelFormat.TRANSLUCENT)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Handle tap on touchpad (center)
        if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER) {
            openOptionsMenu()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        when (event?.action) {
            MotionEvent.ACTION_DOWN -> {
                xDown = event.x
                yDown = event.y
                return true
            }
            MotionEvent.ACTION_UP -> {
                val xDiff = xDown - event.x
                val yDiff = yDown - event.y

                // Detect swipe down (for Google Glass)
                if (yDiff < -100 && Math.abs(xDiff) < Math.abs(yDiff)) {
                    FaceEnrollmentActivity.start(this)
                    return true
                }
            }
        }
        return super.onTouchEvent(event)
    }

    override fun onResume() {
        super.onResume()
        // Start camera preview if it exists
        openCamera()
    }

    override fun onPause() {
        // Release the Camera in onPause
        releaseCamera()
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        mFaceRecognitionHelper?.cleanup()
    }

    private fun openCamera() {
        if (mCamera == null) {
            try {
                mCamera = Camera.open()

                // Configure camera parameters
                val parameters = mCamera?.parameters
                parameters?.let {
                    if (it.supportedFocusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) {
                        it.focusMode = Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE
                    }

                    // Explicitly set preview format to NV21
                    it.previewFormat = android.graphics.ImageFormat.NV21

                    // Set preview size (use a smaller size for better performance)
                    val sizes = it.supportedPreviewSizes
                    var optimalSize: Camera.Size? = null
                    // Find a good compromise between size and performance
                    for (size in sizes) {
                        if (size.width <= 640 && size.height <= 480) {
                            optimalSize = size
                            break
                        }
                    }

                    if (optimalSize != null) {
                        it.setPreviewSize(optimalSize.width, optimalSize.height)
                        Log.d(TAG, "Set preview size to ${optimalSize.width}x${optimalSize.height}")
                    }

                    mCamera?.parameters = it
                }

                // If surface already exists, set it up immediately
                if (mSurfaceHolder?.surface != null && mSurfaceHolder?.surface?.isValid == true) {
                    startPreview()
                }

                mStatusText?.text = "Camera active - Ready for faces\nTap to open menu, swipe down to enroll face"
                Log.d(TAG, "Camera opened successfully")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to open camera: ${e.message}")
                mStatusText?.text = "CAMERA ERROR: ${e.message}"
            }
        }
    }

    private fun startPreview() {
        try {
            mCamera?.apply {
                setPreviewDisplay(mSurfaceHolder)

                // Simple approach: use basic preview callback
                setPreviewCallback { data, camera ->
                    Log.d(TAG, "Frame received")
                    onPreviewFrame(data, camera)
                }

                startPreview()
            }
        } catch (e: IOException) {
            Log.e(TAG, "Error setting camera preview: ${e.message}")
            mStatusText?.text = "PREVIEW ERROR: ${e.message}"
        }
    }

    private fun releaseCamera() {
        mCamera?.apply {
            setPreviewCallback(null)
            stopPreview()
            release()
        }
        mCamera = null
        Log.d(TAG, "Camera released")
    }

    // Camera.PreviewCallback implementation
    override fun onPreviewFrame(data: ByteArray?, camera: Camera?) {
        Log.d(TAG, "Frame received") // Add this
        if (data == null || camera == null || isProcessingFrame) {
            Log.d(TAG, "Skipping frame - data null: ${data == null}, camera null: ${camera == null}, isProcessing: $isProcessingFrame")
            return
        }

        // Process every 100 frames for better performance
        frameCounter++
        if (frameCounter % 100 != 0) {
            return
        }

        Log.d(TAG, "Processing frame #$frameCounter")

        // Get camera parameters
        val parameters = camera.parameters
        val width = parameters.previewSize.width
        val height = parameters.previewSize.height

        // Add debug log
        Log.d(TAG, "Processing frame: $width x $height")

        // Process the frame in a separate thread
        isProcessingFrame = true
        Thread {
            try {
                // Convert YUV to Bitmap
                val bitmap = convertYuvToBitmap(data, width, height)

                // Detect faces
                val faces = mFaceRecognitionHelper?.detectFaces(bitmap) ?: emptyList()
                Log.d(TAG, "Detected ${faces.size} faces in preview")

                // Process each face
                val recognizedFaces = mutableListOf<Pair<Rect, String>>()
                for (faceRect in faces) {
                    val name = mFaceRecognitionHelper?.recognizeFace(bitmap, faceRect, 0.9f) ?: "Unknown"
                    recognizedFaces.add(Pair(faceRect, name))
                    Log.d(TAG, "Recognized face: $name at $faceRect")
                }

                // Update UI on main thread
                runOnUiThread {
                    // Force update overlay
                    mOverlayView?.updateFaces(recognizedFaces)
                    mOverlayView?.invalidate()

                    // Update status text
                    if (recognizedFaces.isEmpty()) {
                        mStatusText?.text = "No faces detected\nTap to open menu, swipe down to enroll face"
                    } else {
                        val facesText = recognizedFaces.joinToString(", ") { it.second }
                        mStatusText?.text = "Detected: $facesText\nTap to open menu, swipe down to enroll face"
                    }
                }

                bitmap.recycle()
            } catch (e: Exception) {
                Log.e(TAG, "Error processing frame: ${e.message}")
                e.printStackTrace() // Add stack trace for better debugging
                runOnUiThread {
                    mStatusText?.text = "Processing error: ${e.message}"
                }
            } finally {
                isProcessingFrame = false
            }
        }.start()
    }

    private fun convertYuvToBitmap(data: ByteArray, width: Int, height: Int): Bitmap {
        Log.d(TAG, "Converting YUV data to bitmap: $width x $height")

        // Create grayscale bitmap (simpler and much faster)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(width * height)

        // Simple Y-only conversion (ignore UV)
        for (i in 0 until width * height) {
            val y = data[i].toInt() and 0xFF
            pixels[i] = -0x1000000 or (y shl 16) or (y shl 8) or y
        }

        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
        Log.d(TAG, "Conversion complete")
        return bitmap
    }

    // SurfaceHolder.Callback implementations
    override fun surfaceCreated(holder: SurfaceHolder) {
        Log.d(TAG, "Surface created")
        // The Surface has been created, now start the camera preview
        startPreview()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        Log.d(TAG, "Surface changed")
        if (mSurfaceHolder?.surface == null) {
            return
        }

        try {
            mCamera?.stopPreview()
        } catch (e: Exception) {
            // Ignore: tried to stop a non-existent preview
        }

        startPreview()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        Log.d(TAG, "Surface destroyed")
    }

    // Custom view for drawing face overlays
    inner class OverlayView(context: android.content.Context) : android.view.View(context) {
        private val paint = Paint().apply {
            color = Color.GREEN
            style = Paint.Style.STROKE
            strokeWidth = 5f  // Make lines thicker
        }

        private val textPaint = Paint().apply {
            color = Color.WHITE
            textSize = 32f  // Larger text
            style = Paint.Style.FILL
            setShadowLayer(3f, 1f, 1f, Color.BLACK)
        }

        private val backgroundPaint = Paint().apply {
            color = Color.argb(180, 0, 0, 0)  // More opaque background
            style = Paint.Style.FILL
        }

        private var faces = listOf<Pair<Rect, String>>()

        fun updateFaces(newFaces: List<Pair<Rect, String>>) {
            if (newFaces.isNotEmpty()) {
                Log.d(TAG, "Updating overlay with ${newFaces.size} faces")
            }
            faces = newFaces
            invalidate()  // Request redraw
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            Log.d(TAG, "Drawing overlay with ${faces.size} faces")

            // Add debug log
            if (faces.isNotEmpty()) {
                Log.d(TAG, "Drawing ${faces.size} faces on overlay")
            }

            // Scale factors for converting camera coordinates to view coordinates
            val scaleX = width.toFloat() / (mCamera?.parameters?.previewSize?.width ?: 1)
            val scaleY = height.toFloat() / (mCamera?.parameters?.previewSize?.height ?: 1)

            for ((rect, name) in faces) {
                // Scale the rectangle to match the view size
                val scaledRect = Rect(
                    (rect.left * scaleX).toInt(),
                    (rect.top * scaleY).toInt(),
                    (rect.right * scaleX).toInt(),
                    (rect.bottom * scaleY).toInt()
                )

                // Draw an attention-grabbing face rectangle
                paint.color = Color.GREEN
                canvas.drawRect(scaledRect, paint)

                // Add a second contrasting outline
                paint.color = Color.YELLOW
                paint.strokeWidth = 2f
                val outlineRect = Rect(
                    scaledRect.left - 2,
                    scaledRect.top - 2,
                    scaledRect.right + 2,
                    scaledRect.bottom + 2
                )
                canvas.drawRect(outlineRect, paint)

                // Draw name with background for better visibility
                val textWidth = textPaint.measureText(name)
                val textBgRect = Rect(
                    scaledRect.left,
                    scaledRect.top - 40,
                    (scaledRect.left + textWidth + 16).toInt(),
                    scaledRect.top
                )

                canvas.drawRect(textBgRect, backgroundPaint)
                canvas.drawText(
                    name,
                    scaledRect.left + 8f,
                    scaledRect.top - 10f,
                    textPaint
                )
            }
        }
    }
}